//
//  Goal.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/29.
//

import Foundation
import SwiftUI

struct Goal {
    var mainGoal: String = "실리콘벨리에서 일하고 싶다"
    
    var subGoals: [(subGoal: String, degree: Int)] = [
        ("Toeic Speaking", 7),
        ("해리포터 자막 없이 보기", 16),
        ("비행기 표 돈 모으기", 2),
        ("SwiftUI 프로젝트 만들어보기", 9)
    ]
    
    var goalColors: [Color] = [
        Color("Pink"),
        Color("LightPurple"),
        Color("LightBeige")
    ]
    
    mutating func addSubGoal(subGoal: String) {
        subGoals.append((subGoal: subGoal, degree: 0))
    }
    
    func getGoalColors() -> [Color]{
        return goalColors
    }
    
    func getMainGoal() -> String {
        return mainGoal
    }
    func getSubGoals() -> [(subGoal: String, degree: Int)] {
        return subGoals
    }
    
    mutating func increaseDegree(index: Int) {
        if subGoals[index].degree < 20 {
            subGoals[index].degree += 1
        }
    }
    mutating func decreaseDegree(index: Int) {
        if subGoals[index].degree > 0 {
            subGoals[index].degree -= 1
        }
    }
    
    func getAvg() -> Double {
        var avg: Double = 0
        for i in 0..<subGoals.count {
            avg += Double(subGoals[i].degree) / 20
        }
        return avg / Double(subGoals.count) * 100
    }
    
    mutating func removeSubGoal(index: Int) {
        subGoals.remove(at: index)
    }
}
