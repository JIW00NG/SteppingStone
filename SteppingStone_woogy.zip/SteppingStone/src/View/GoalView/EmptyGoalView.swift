//
//  EmptyGoalView.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/29.
//

import Foundation
import SwiftUI

struct EmptyGoalView: View {
    @State var isModalShown = false
    
    var body: some View {
        Button(action: {
            self.isModalShown = true
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(Color("StrokeColor"), lineWidth: 3)
                Circle()
                    .strokeBorder(Color("LightPastelBlue"), lineWidth: 2)
                    .padding(EdgeInsets(top: 20, leading: 20, bottom: 17, trailing: 20))
                    .frame(width: 68, height: 68)
                Text("+").foregroundColor(Color("LightPastelBlue"))
            }
        }.sheet(isPresented: self.$isModalShown) {
            NavigationView {
                SetGoalView()
                    .navigationBarTitle("목표 설정", displayMode: .inline)
                    .navigationBarItems(trailing: Button("Done", action: {}))
                    .navigationBarItems(leading: Button("Cancel", action: {}))
            }
        }
        .padding(.leading)
        .padding(.trailing)
    }
}
