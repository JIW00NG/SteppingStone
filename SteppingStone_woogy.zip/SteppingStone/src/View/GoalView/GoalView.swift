//
//  GoalView.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/28.
//

import Foundation
import SwiftUI

struct GoalView: View {
    @State var goal: Goal = Goal()
    
    var body: some View {
        VStack {
            ZStack (alignment: .top){
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(Color("StrokeColor"), lineWidth: 3)
                VStack {
                    Text(goal.getMainGoal()).font(.headline).bold()
                    
                    circlurProgress(goal: $goal)
                    
                    Divider()
                        .background(Color("StrokeColor"))
                        .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
                    ScrollView {
                        LazyVStack {
                            ForEach(0..<goal.subGoals.count, id: \.self) { index in
                                SubGoalItem(goal: $goal, goalIndex: index)
                                    .listRowSeparator(.hidden)
                                    .contextMenu {
                                    }
                            }
                            AddSubGoalButton(goal: $goal)
                        }
                    }
                }.padding()
            }
        }
        .padding(.leading)
        .padding(.trailing)
    }
}

struct GoalView_Previews: PreviewProvider {
    static var previews: some View {
        GoalView()
    }
}
