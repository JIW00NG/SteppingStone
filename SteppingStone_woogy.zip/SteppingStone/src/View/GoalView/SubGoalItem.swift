//
//  subGoalItem.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/29.
//

import Foundation
import SwiftUI

struct SubGoalItem: View {
    @Binding var goal: Goal
    @State var goalIndex: Int
    
    let goalsViewWidth = (UIScreen.main.bounds.width - 138)
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(goal.getGoalColors()[goalIndex % 3])
            HStack {
                Button(action: {
                    goal.decreaseDegree(index: goalIndex)
                }) {
                    Text("-").foregroundColor(.gray)
                }
                .padding(EdgeInsets(top: 0, leading: 15, bottom: 0, trailing: 5))
                .frame(height: 64)
                
                ZStack {
                    Rectangle().fill(.white.opacity(0.8))
                    
                    HStack {
                        Rectangle().fill(goal.getGoalColors()[goalIndex % 3]).frame(width: (Double(goal.getSubGoals()[goalIndex].degree) / 20.0) * goalsViewWidth)
                            .frame(alignment: .leading)
                        if goal.getSubGoals()[goalIndex].degree != 20 {
                            Spacer()
                        }
                    }
                    Text("\(goal.getSubGoals()[goalIndex].subGoal)").font(.subheadline)
                }
                
                Button(action: {
                    goal.increaseDegree(index: goalIndex)
                }) {
                    Text("+").foregroundColor(.gray)
                }
                .padding(EdgeInsets(top: 0, leading: 5, bottom: 0, trailing: 15))
                .frame(height: 64)
            }
        }
        .frame(height: 64)
        .contextMenu {
            Button(action: {
                print("delete \(goalIndex) sub goal")
                goal.removeSubGoal(index: goalIndex)
            }, label: {
                Text("Delete")
                Spacer()
                Image(systemName: "trash")
            })
        }
    }
}
