//
//  SetSubGoalItem.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/30.
//

import Foundation
import SwiftUI

struct SetSubGoalItem: View {
    var body: some View {
        Text("")
    }
}

struct AddSubGoalButton: View {
    @Binding var goal: Goal
    
    var body: some View {
        Button(action: {
//            print("add Sub Goal")
            goal.addSubGoal(subGoal: "실리콘벨리 알아보기")
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(Color("LightPastelBlue"), lineWidth: 3)
                Circle()
                    .strokeBorder(Color("LightPastelBlue"), lineWidth: 2)
                    .padding(EdgeInsets(top: 20, leading: 20, bottom: 17, trailing: 20))
                Text("+").foregroundColor(Color("LightPastelBlue"))
            }
        }
        .listRowSeparator(.hidden)
        .frame(height: 64)
    }
}
