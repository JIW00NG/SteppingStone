//
//  SetGoalView.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/28.
//

import Foundation
import SwiftUI

struct SetGoalView: View {
    var body: some View {
        Text("Hello, World!")
    }
}
