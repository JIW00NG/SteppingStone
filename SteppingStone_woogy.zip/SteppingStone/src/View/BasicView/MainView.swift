//
//  MainView.swift
//  SteppingStone
//
//  Created by JiwKang on 2022/04/28.
//

import Foundation
import SwiftUI

struct MainView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("\(getCurrentDate())").font(.headline)
                .padding(.top)
                .padding(.leading)
                .padding(.trailing)
            TabView {
                GoalView()
                EmptyGoalView()
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
        }
    }
}

func getCurrentDate() -> String {
    let currentDate = Date()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "MMM d, yyyy"
    return dateFormatter.string(from: currentDate)
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
